
#include <iostream>
#include <vector>
#include <chrono>
#include <iomanip>
#include <cuda_runtime.h>
#include <thrust/device_ptr.h>
#include <thrust/sort.h>

// Macro for GPU API error checking with real-time file and line reporting
#define CHECK_CUDA(call) { \
    cudaError_t err = call; \
    if (err != cudaSuccess) { \
        std::cerr << "CUDA Error: " << cudaGetErrorString(err) << " at line " << __LINE__ << std::endl; \
        exit(1); \
    } \
}

/**
 * @brief Generates pseudo-random weights for the modular oracle projection on Host.
 */
void generate_oracle_weights(std::vector<uint64_t>& weights, int d, uint64_t Q) {
    uint64_t seed = 987654321ULL;
    for (int i = 0; i < d; ++i) {
        seed ^= seed << 21; seed ^= seed >> 35; seed ^= seed << 4;
        weights[i] = seed % Q;
    }
}

/**
 * @brief Evaluates the modular linear projection of a sub-vector on GPU Device.
 */
__device__ uint64_t project_residue(uint64_t vector_id, int dim,
                                     const uint64_t* weights, uint64_t Q) {
    long long sum = 0;
    uint64_t temp = vector_id;
    for (int i = 0; i < dim; ++i) {
        long long coef = (long long)(temp % 3) - 1; // Map base-3 digit to {-1, 0, 1}
        sum = (sum + coef * (long long)weights[i]) % (long long)Q;
        temp /= 3;
    }
    if (sum < 0) sum += (long long)Q;
    return static_cast<uint64_t>(sum);
}

/**
 * @brief Evaluates the modular linear projection of a sub-vector on Host CPU.
 */
uint64_t project_residue_host(uint64_t vector_id, int dim,
                               const uint64_t* weights, uint64_t Q) {
    long long sum = 0;
    uint64_t temp = vector_id;
    for (int i = 0; i < dim; ++i) {
        long long coef = (long long)(temp % 3) - 1; // Map base-3 digit to {-1, 0, 1}
        sum = (sum + coef * (long long)weights[i]) % (long long)Q;
        temp /= 3;
    }
    if (sum < 0) sum += (long long)Q;
    return static_cast<uint64_t>(sum);
}

/**
 * @brief Forward Stage Kernel: Computes partial modular projections for the first half of the secret.
 */
__global__ void forward_kernel(uint64_t total_states, int half_d,
                               const uint64_t* d_weights, uint64_t Q,
                               uint64_t* d_table) {
    uint64_t id = (uint64_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (id < total_states) {
        d_table[id] = project_residue(id, half_d, d_weights, Q);
    }
}

/**
 * @brief Backward Stage Kernel: Computes target complement residues and performs parallel binary search.
 */
__global__ void backward_kernel(uint64_t total_states, int half_d,
                                const uint64_t* d_weights, uint64_t Q,
                                uint64_t target,
                                const uint64_t* __restrict__ d_table,
                                unsigned long long* d_survivors) {
    uint64_t id = (uint64_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (id >= total_states) return;

    uint64_t my_residue = project_residue(id, half_d, d_weights, Q);
    uint64_t target_val = ((long long)target + (long long)Q - (long long)my_residue) % (long long)Q;

    // Binary search lower bound
    uint64_t left = 0;
    uint64_t right = total_states;
    while (left < right) {
        uint64_t mid = left + (right - left) / 2;
        if (d_table[mid] < target_val) left = mid + 1;
        else right = mid;
    }

    // Count collisions in the sorted Forward table
    if (left < total_states && d_table[left] == target_val) {
        unsigned long long collisions = 0;
        while (left + collisions < total_states && d_table[left + collisions] == target_val) {
            collisions++;
        }
        atomicAdd(d_survivors, collisions);
    }
}

struct Result {
    unsigned long long survivors;
    float time_forward_ms;
    float time_sort_ms;
    float time_backward_ms;
    bool secret_consistent;
};

/**
 * @brief Executes a complete MitM evaluation for a given oracle norm configuration Q.
 */
Result run_configuration(int d, int half_d, uint64_t total_states,
                         uint64_t Q, uint64_t secret_id) {
    Result res = {0, 0, 0, 0, false};

    std::vector<uint64_t> weights(d);
    generate_oracle_weights(weights, d, Q);

    uint64_t target = project_residue_host(secret_id, d, weights.data(), Q);

    uint64_t* d_weights;
    CHECK_CUDA(cudaMalloc(&d_weights, d * sizeof(uint64_t)));
    CHECK_CUDA(cudaMemcpy(d_weights, weights.data(), d * sizeof(uint64_t),
                          cudaMemcpyHostToDevice));

    uint64_t* d_table;
    CHECK_CUDA(cudaMalloc(&d_table, total_states * sizeof(uint64_t)));

    unsigned long long* d_survivors;
    CHECK_CUDA(cudaMalloc(&d_survivors, sizeof(unsigned long long)));
    CHECK_CUDA(cudaMemset(d_survivors, 0, sizeof(unsigned long long)));

    int blockSize = 256;
    int numBlocks = (int)((total_states + blockSize - 1) / blockSize);

    cudaEvent_t t0, t1, t2, t3, t4, t5;
    cudaEventCreate(&t0); cudaEventCreate(&t1); cudaEventCreate(&t2);
    cudaEventCreate(&t3); cudaEventCreate(&t4); cudaEventCreate(&t5);

    // Forward Generation Stage
    cudaEventRecord(t0);
    forward_kernel<<<numBlocks, blockSize>>>(total_states, half_d, d_weights, Q, d_table);
    cudaEventRecord(t1);
    CHECK_CUDA(cudaDeviceSynchronize());

    // Parallel VRAM Radix Sorting Stage (NVIDIA Thrust)
    cudaEventRecord(t2);
    thrust::device_ptr<uint64_t> thrust_ptr(d_table);
    thrust::sort(thrust_ptr, thrust_ptr + total_states);
    cudaEventRecord(t3);
    CHECK_CUDA(cudaDeviceSynchronize());

    // Backward Interception Stage (Using second half of weights: d_weights + half_d)
    cudaEventRecord(t4);
    backward_kernel<<<numBlocks, blockSize>>>(total_states, half_d, d_weights + half_d, Q,
                                               target, d_table, d_survivors);
    cudaEventRecord(t5);
    CHECK_CUDA(cudaDeviceSynchronize());

    cudaEventElapsedTime(&res.time_forward_ms, t0, t1);
    cudaEventElapsedTime(&res.time_sort_ms, t2, t3);
    cudaEventElapsedTime(&res.time_backward_ms, t4, t5);

    CHECK_CUDA(cudaMemcpy(&res.survivors, d_survivors,
                          sizeof(unsigned long long), cudaMemcpyDeviceToHost));

    uint64_t target_check = project_residue_host(secret_id, d, weights.data(), Q);
    res.secret_consistent = (target_check == target);

    cudaFree(d_weights); cudaFree(d_table); cudaFree(d_survivors);
    return res;
}

int main() {
    int d = 36;
    int half_d = d / 2;
    uint64_t total_states = 387420489ULL; // 3^18 states per half
    uint64_t secret_id = 123456789ULL;

    cudaDeviceProp prop;
    cudaGetDeviceProperties(&prop, 0);
    std::cout << "=================================================================\n";
    std::cout << " EXTREME CUDA MITM ENGINE (d=36) — ROBUST v3\n";
    std::cout << "=================================================================\n";
    std::cout << " Device       : " << prop.name << " (SM " << prop.major << "." << prop.minor << ")\n";
    std::cout << " CUDA Runtime : " << CUDART_VERSION << "\n";
    std::cout << " Compiler     : nvcc " << __VERSION__ << "\n";
    std::cout << " Seed         : 987654321ULL\n";
    std::cout << " Secret ID    : " << secret_id << "\n";
    std::cout << "-----------------------------------------------------------------\n";
    std::cout << " Dimension d  : " << d << "\n";
    std::cout << " Total states : 3^36 = 150094635296999121\n\n";

    uint64_t Q_A = 15000000000000000ULL;
    uint64_t Q_B = 150000000000000ULL;

    std::cout << "[Regime Analysis: Q vs |S|]\n";
    std::cout << " Config |        Q         | Q/|S|    | E[Omega]\n";
    std::cout << " -------|------------------|----------|----------\n";
    std::cout << " A      | " << Q_A << " | " << std::fixed << std::setprecision(4)
              << (double)Q_A / 150094635296999121.0 << "   | "
              << 150094635296999121.0 / (double)Q_A << "\n";
    std::cout << " B      | " << Q_B << " | " << std::fixed << std::setprecision(4)
              << (double)Q_B / 150094635296999121.0 << "   | "
              << 150094635296999121.0 / (double)Q_B << "\n\n";

    std::cout << "[Config A: Canonical Regime (Q ≈ 0.1|S|)]\n";
    Result resA = run_configuration(d, half_d, total_states, Q_A, secret_id);
    double theoryA = 150094635296999121.0 / (double)Q_A;
    std::cout << " Forward  : " << resA.time_forward_ms << " ms\n";
    std::cout << " Sort     : " << resA.time_sort_ms << " ms\n";
    std::cout << " Backward : " << resA.time_backward_ms << " ms\n";
    std::cout << " Total    : " << (resA.time_forward_ms + resA.time_sort_ms + resA.time_backward_ms) / 1000.0 << " s\n";
    std::cout << " Theoretical E[Omega] : " << std::setprecision(6) << theoryA << "\n";
    std::cout << " Empirical survivors  : " << resA.survivors << "\n";
    std::cout << " Ratio emp/theo       : " << std::setprecision(4)
              << (double)resA.survivors / theoryA << "\n";
    std::cout << " Secret consistent    : " << (resA.secret_consistent ? "YES" : "NO") << "\n\n";

    std::cout << "[Config B: Transition Regime (Q ≈ 0.001|S|)]\n";
    Result resB = run_configuration(d, half_d, total_states, Q_B, secret_id);
    double theoryB = 150094635296999121.0 / (double)Q_B;
    std::cout << " Forward  : " << resB.time_forward_ms << " ms\n";
    std::cout << " Sort     : " << resB.time_sort_ms << " ms\n";
    std::cout << " Backward : " << resB.time_backward_ms << " ms\n";
    std::cout << " Total    : " << (resB.time_forward_ms + resB.time_sort_ms + resB.time_backward_ms) / 1000.0 << " s\n";
    std::cout << " Theoretical E[Omega] : " << std::setprecision(6) << theoryB << "\n";
    std::cout << " Empirical survivors  : " << resB.survivors << "\n";
    std::cout << " Ratio emp/theo       : " << std::setprecision(4)
              << (double)resB.survivors / theoryB << "\n";
    std::cout << " Secret consistent    : " << (resB.secret_consistent ? "YES" : "NO") << "\n\n";

    std::cout << "=================================================================\n";
    return 0;
}
