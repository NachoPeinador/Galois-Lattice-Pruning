import Mathlib.Data.Real.Basic
import Mathlib.Tactic.Ring

set_option linter.style.longLine false

/-!
# Module: Oracle Independence Law & Entropy Collapse
# Certifies Corollary 4.1: Asymptotic elimination rate of lattice branches.
-/

namespace RingLWE.OracleIndependence

/-- The expected number of surviving nodes over the ternary space. -/
noncomputable def expected_nodes (d : ℕ) (q_prod : ℝ) : ℝ :=
  (3 : ℝ)^d / q_prod

/-- Asymptotic pruning rate based on the expectation limit. -/
noncomputable def pruning_rate (d : ℕ) (q_prod : ℝ) : ℝ :=
  1 - expected_nodes d q_prod / (3 : ℝ)^d

/--
THEOREM: Asymptotic Nodal Pruning Rate.
Certifies the exact volumetric collapse of the search space.
-/
theorem pruning_rate_formula (d : ℕ) (q_prod : ℝ) (h_d : (3 : ℝ)^d ≠ 0) :
    pruning_rate d q_prod = 1 - 1 / q_prod := by
  dsimp [pruning_rate, expected_nodes]
  calc
    1 - ((3 : ℝ)^d / q_prod) / (3 : ℝ)^d
      = 1 - ((3 : ℝ)^d / (3 : ℝ)^d) * (1 / q_prod) := by ring
    _ = 1 - 1 * (1 / q_prod) := by rw [div_self h_d]
    _ = 1 - 1 / q_prod := by ring

end RingLWE.OracleIndependence
