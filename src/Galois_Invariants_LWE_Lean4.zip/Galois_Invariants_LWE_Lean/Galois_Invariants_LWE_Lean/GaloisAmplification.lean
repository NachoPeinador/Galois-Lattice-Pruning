import Mathlib.Data.Nat.Basic

set_option linter.style.longLine false

/-!
# Module: Galois Invariants Amplification
# Certifies Theorem 3.1: Effective norm amplification over conjugate ideals.
-/

namespace RingLWE.GaloisInvariants

/-- Definition of the effective norm amplified by the Galois orbit size g. -/
def effective_norm (q g : ℕ) : ℕ := q ^ g

/--
THEOREM: Galois Orbit Amplification Factor.
Certifies that the effective norm Q_eff = q^g equals exactly p^n
when the prime ideal norm is q = p^f and the orbit size is g = n/f.
-/
theorem galois_amplification (p f g n q : ℕ) (hq : q = p^f) (hn : n = f * g) :
    effective_norm q g = p^n := by
  dsimp [effective_norm]
  rw [hq, ← pow_mul, mul_comm f g, ← hn]

end RingLWE.GaloisInvariants
