import Mathlib.NumberTheory.KummerDedekind
import Mathlib.RingTheory.DedekindDomain.Factorization
import Mathlib.RingTheory.DedekindDomain.Basic
import Mathlib.RingTheory.Conductor
import Mathlib.Data.ZMod.Basic
import Mathlib.Tactic.NormNum

set_option linter.style.longLine false

/-!
# Module: KummerDedekindApplied

Concrete applications of the Kummer-Dedekind theorem to specific
number-theoretic settings.

The abstract theorem itself is certified in Mathlib4
(`Mathlib.NumberTheory.KummerDedekind`, Baanen-Lezeau, 2021). This module
illustrates its application to:

  1. The Gauss integers Z[i] at p = 5.
  2. The general splitting pattern for x² + 1 modulo a prime.

## Reference

Baanen, A., Lezeau, P. (2021). Kummer-Dedekind theorem.
`Mathlib.NumberTheory.KummerDedekind`, Mathlib4.
-/

namespace KummerDedekindApplied

-- =============================================================================
-- SECTION 1: THE GAUSS CASE — x² + 1 in F_5[x]
-- =============================================================================

/-- The Gauss polynomial X² + 1, defining Z[i] = Z[X]/(X² + 1). -/
def gaussPoly : Polynomial Int := Polynomial.X ^ 2 + 1

/-- The reduction of the Gauss polynomial modulo 5. -/
theorem gaussPoly_reduction_mod_5 :
    (gaussPoly.map (Int.castRingHom (ZMod 5))) =
    (Polynomial.X ^ 2 + 1 : Polynomial (ZMod 5)) := by
  unfold gaussPoly
  simp [Polynomial.map_add, Polynomial.map_pow, Polynomial.map_X, Polynomial.map_one]

/-- In F_5[X], x² + 1 = (x - 2)(x - 3). -/
theorem gaussPoly_factorization_mod_5 :
    (Polynomial.X ^ 2 + 1 : Polynomial (ZMod 5)) =
    (Polynomial.X - Polynomial.C (2 : ZMod 5)) *
    (Polynomial.X - Polynomial.C (3 : ZMod 5)) := by
  ext n
  simp [Polynomial.coeff_X_pow, Polynomial.coeff_sub, Polynomial.coeff_mul,
        Polynomial.coeff_C]
  ring_nf
  norm_num [ZMod.natCast_self]

/-- The roots 2 and 3 are distinct in F_5. -/
theorem gaussPoly_roots_distinct :
    (2 : ZMod 5) ≠ 3 := by norm_num

/-- The reduction map on polynomials is compatible with evaluation. -/
theorem reduction_eval_2 :
    (Polynomial.eval (2 : ZMod 5) (Polynomial.X ^ 2 + 1)) = 0 := by
  norm_num

theorem reduction_eval_3 :
    (Polynomial.eval (3 : ZMod 5) (Polynomial.X ^ 2 + 1)) = 0 := by
  norm_num

-- =============================================================================
-- SECTION 2: SPLITTING PATTERN OF X² + 1 MOD p
-- =============================================================================

/-- In F_2[X], x² + 1 = (x + 1)². -/
theorem gaussPoly_factorization_mod_2 :
    (Polynomial.X ^ 2 + 1 : Polynomial (ZMod 2)) =
    (Polynomial.X + 1) * (Polynomial.X + 1) := by
  ext n
  simp [Polynomial.coeff_X_pow, Polynomial.coeff_add, Polynomial.coeff_mul,
        Polynomial.coeff_C, Polynomial.coeff_one]
  ring_nf
  norm_num

/-- In F_3[X], x² + 1 is irreducible (i.e., -1 is a non-residue mod 3). -/
theorem gaussPoly_irreducible_mod_3 :
    ∀ x : ZMod 3, x ^ 2 + 1 ≠ 0 := by
  intro x
  fin_cases x <;> norm_num

-- =============================================================================
-- SECTION 3: THE CONDUCTOR HYPOTHESIS IN THE GAUSS CASE
-- =============================================================================

/-- The hypothesis that p does not divide the conductor of Z[i] in O_K.

For Z[i] = O_{Q(i)}, the ring Z[i] is integrally closed, so the conductor
is the whole ring and the hypothesis is trivially satisfied for any p. -/
theorem conductor_hypothesis_satisfied_gauss (p : ℕ) [Fact p.Prime] :
    (conductor ℤ (Polynomial.X : Polynomial ℤ)).comap
      (algebraMap ℤ (Polynomial ℤ)) ⊔ Ideal.span {(p : Polynomial ℤ)} = ⊤ := by
  -- The conductor of Z[x] in Z[x] is the whole ring, so the supremum is ⊤.
  -- This is a formal placeholder reflecting the mathematical fact.
  sorry

-- =============================================================================
-- SECTION 4: STRUCTURAL DOCUMENTATION OF THE REUSE PATTERN
-- =============================================================================

/-!
## The reuse pattern for Mathlib4's Kummer-Dedekind theorem

To apply `normalizedFactors_ideal_map_eq_normalizedFactors_min_poly_mk_map`
to a concrete case, the following ingredients are required:

1. **A Dedekind domain R** (base ring).
2. **A Dedekind domain S** that is an R-algebra.
3. **An element x : S** integral over R.
4. **The minimal polynomial** of x over R.
5. **A maximal ideal I of R** such that the conductor of x is coprime to I.

The theorem then states that the factorization of I * S in S matches the
factorization of minpoly(x) mod I in (R/I)[X].

### Example: Z[i] at p = 5

- R = Z (Dedekind domain).
- S = Z[i] = Z[X]/(X² + 1) (Dedekind domain, since Z[i] is integrally closed).
- x = i (integral over Z, minimal polynomial X² + 1).
- I = (5) (maximal ideal of Z).
- Conductor of i: since Z[i] is integrally closed, conductor = Z[i], so
  conductor ∩ Z = Z, which is coprime to (5).

**Conclusion:** the factorization of (5) in Z[i] matches the factorization
of X² + 1 mod 5 in F_5[X]. Since X² + 1 = (X - 2)(X - 3) in F_5[X], the
ideal (5) splits into two prime ideals in Z[i]: (5) = (5, i - 2)(5, i - 3).

### Formal instantiation

The formal verification of this application requires discharging the
conductor hypothesis, which in the Gauss case is trivially satisfied
because Z[i] is integrally closed. The formal proof of this fact is
currently marked with `sorry` because it requires additional infrastructure
for the integral-closedness of Z[i] that is beyond the scope of this
notebook. The mathematical statement is correct and follows from the
general theory.
-/

-- =============================================================================
-- SECTION 5: VERIFICATION OF THE MATHEMATICAL PREDICTION
-- =============================================================================

/-- In F_5[X], x² + 1 splits into exactly two linear factors. This is
consistent with the Kummer-Dedekind prediction that (5) splits into two
prime ideals in Z[i]. -/
theorem gauss_splitting_pattern :
    ∃ a b : ZMod 5,
      a ≠ b ∧
      (Polynomial.X ^ 2 + 1 : Polynomial (ZMod 5)) =
      (Polynomial.X - Polynomial.C a) * (Polynomial.X - Polynomial.C b) := by
  exact ⟨2, 3, by norm_num, gaussPoly_factorization_mod_5⟩

/-- In F_2[X], x² + 1 = (x + 1)² is a perfect square. This is consistent
with the Kummer-Dedekind prediction that (2) is totally ramified in Z[i]. -/
theorem gauss_ramification_mod_2 :
    ∃ a : ZMod 2,
      (Polynomial.X ^ 2 + 1 : Polynomial (ZMod 2)) =
      (Polynomial.X - Polynomial.C a) ^ 2 := by
  refine ⟨1, ?_⟩
  rw [gaussPoly_factorization_mod_2]
  ring

/-- In F_3[X], x² + 1 has no roots. This is consistent with the
Kummer-Dedekind prediction that (3) is inert in Z[i]. -/
theorem gauss_inertia_mod_3 :
    ∀ x : ZMod 3, Polynomial.eval x (Polynomial.X ^ 2 + 1) ≠ 0 := by
  intro x
  fin_cases x <;> norm_num

end KummerDedekindApplied
