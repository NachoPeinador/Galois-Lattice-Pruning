import Mathlib.RingTheory.Ideal.Operations
import Mathlib.Algebra.Ring.Equiv

set_option linter.style.longLine false

/-!
# Module: Galois Projection Compatibility

# PURPOSE
# This module certifies the Galois projection compatibility lemma, which is
# the mathematically correct core of the conjugate residue analysis. It states
# that a Galois automorphism sigma : R -> R preserving an ideal (sigma(p1) = p2)
# is compatible with the canonical projections R -> R/p1 and R -> R/p2.

# IMPORTANT EPISTEMIC NOTE
# This module certifies that the map sigma_bar : R/p1 -> R/p2 induced by sigma is
# WELL-DEFINED. It does NOT certify that knowing pi_p1(s) alone determines
# pi_p2(s) for an arbitrary s in R. The latter claim is FALSE in general.
-/

namespace RingLWE.AdvancedLattice

/--
THEOREM: Galois Projection Compatibility.
Certifies that if sigma : R -> R is a ring automorphism with sigma(p1) = p2,
then for any two elements s1, s2 in R,
    s1 - s2 in p1  ==>  sigma(s1) - sigma(s2) in p2.
Equivalently, the induced map sigma_bar : R/p1 -> R/p2 is well-defined.
-/
theorem galois_projection_compatibility {R : Type*} [CommRing R]
    (p1 p2 : Ideal R) (sigma : R ≃+* R)
    (h_map : p1.map (sigma : R →+* R) = p2)
    (s1 s2 : R) (h_eq : s1 - s2 ∈ p1) :
    sigma s1 - sigma s2 ∈ p2 := by
  rw [← map_sub]
  rw [← h_map]
  exact Ideal.mem_map_of_mem (sigma : R →+* R) h_eq

/--
COROLLARY: Well-definedness of the induced map on quotient rings.
-/
theorem induced_map_well_defined {R : Type*} [CommRing R]
    (p1 p2 : Ideal R) (sigma : R ≃+* R)
    (h_map : p1.map (sigma : R →+* R) = p2) :
    ∀ s1 s2 : R, s1 - s2 ∈ p1 → sigma s1 - sigma s2 ∈ p2 := by
  intro s1 s2 h_eq
  exact galois_projection_compatibility p1 p2 sigma h_map s1 s2 h_eq

end RingLWE.AdvancedLattice
